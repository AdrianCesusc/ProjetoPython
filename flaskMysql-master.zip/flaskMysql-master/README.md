# flaskMysql

Projeto com Python, Flask e Mysql
